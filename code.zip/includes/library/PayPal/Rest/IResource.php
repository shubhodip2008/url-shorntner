<?php

namespace PayPal\Rest;

/**
 * Interface IResource
 *
 * @package PayPal\Rest
 */
interface IResource
{
}
